<?php
define('SABAI_CRON_PHP_SAPI_NAME', 'cli');