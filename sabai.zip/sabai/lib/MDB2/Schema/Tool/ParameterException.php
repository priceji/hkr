<?php

class MDB2_Schema_Tool_ParameterException extends Exception
{}

?>